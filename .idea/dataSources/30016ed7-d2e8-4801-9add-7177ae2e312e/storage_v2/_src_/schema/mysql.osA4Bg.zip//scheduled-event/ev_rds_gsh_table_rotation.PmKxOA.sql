create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2024-10-09 14:24:37'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

